<?php

if (!defined('IN_IA')) {
	exit('Access Denied');
}


return array('version' => '1.0', 'id' => 'article', 'name' => '文章营销');

?>