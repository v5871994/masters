<?php
if (!defined('IN_IA')) 
{
	exit('Access Denied');
}
class H5app_EweiShopV2ComModel extends ComModel 
{
}
?>